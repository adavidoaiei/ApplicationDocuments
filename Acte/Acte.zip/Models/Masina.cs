﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DomainClasses
{
    public class Masina
    {
        public int id;
        public string Marca { get; set; }
        public string NrIdentificare { get; set; }
        public string Culoare { get; set; }
        public DateTime AnFabricatie { get; set; }
    }
}
