﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ActeAuto.Models
{
    public class Mesaj
    {
        public string Tip { get; set; }
        public string Descriere { get; set; }
    }
}